var exec = require('child_process').exec;
var aws = require('aws-sdk');
var fs = require('fs');
var path = require('path');
var s3 = new aws.S3({ apiVersion: '2006-03-01' });
var sqs = new aws.SQS();
var lambda = new aws.Lambda();
var async = require('async');

exports.handler = function(event, context) {
    var params = {
      QueueUrl: 'https://sqs.ap-northeast-1.amazonaws.com/002853820913/open-marathon-testcase',
      AttributeNames: [],
      MaxNumberOfMessages: 1,
      MessageAttributeNames: [],
      WaitTimeSeconds: 0
    };

    // s3.putObject({
    //    Bucket: 'open-marathon',
    //    Key: 'test.txt',
    //    Body: '114514'
    // });

    var ReceiptHandle = '';

    async.waterfall([
        function pollMessage(next) {
            sqs.receiveMessage(params, function(err, data) {
            	if (err) {
            		next(err);
            	} else {
            		next(null, data);
            	}
            });
        },
        function downloadSolutionFile(data, next) {
            if (!data.Messages || data.Messages.length == 0) {
                next('err: no message in queue');
            } else {
                var messageId = data.Messages[0].MessageId;
                ReceiptHandle = data.Messages[0].ReceiptHandle;
                var body = JSON.parse(data.Messages[0].Body);

                var remoteSolutionPath = body.MessageAttributes.solution.Value;
                var remoteGraderPath = body.MessageAttributes.grader.Value;
                var seed = body.MessageAttributes.seed.Value;

                remoteSolutionPath = 'codes/Solution.jar';
                remoteGraderPath = 'grader/SmallPolygonsGrader.jar';

                s3.getObject({
                    Bucket: 'open-marathon',
                    Key: remoteSolutionPath
                }, function(err, data) {
                    if (err) {
                        next(err, 'downloadSolutionFile');
                    } else {
                    	next(null, data, remoteGraderPath, seed);
                    }
                });
            }
        },
        function downloadGraderFile(solution, remoteGraderPath, seed, next) {
            s3.getObject({
                Bucket: 'open-marathon',
                Key: remoteGraderPath
            }, function(err, data) {
                if (err) {
                    next(err, 'downloadGraderFile');
                } else {
                	next(null, solution, data, seed);
                }
            });
        },
        function saveBinaryToFile(solution, grader, seed, next) {
            fs.writeFileSync('/tmp/Solution.jar', solution.Body);
            fs.writeFileSync('/tmp/SmallPolygonsGrader.jar', grader.Body);
            next(null, '/tmp/Solution.jar', '/tmp/SmallPolygonsGrader.jar', seed);
        },
        function executeSolution(solutionPath, graderPath, seed, next) {
            var execCommand = '';
            if (true) {
              execCommand = 'java -jar #1'.replace('#1', solutionPath);
            } else {
              execCommand = 'chmod 700 #1; #1'.replace('#1', solutionPath);
            }
            var command = 'java -jar #1 "#2" #3'
                .replace('#1', graderPath)
                .replace('#2', execCommand)
                .replace('#3', seed);
            console.log('command:' + command)

            var theProcess = exec(command, function(err, stdout, stderr) {
              if (err) {
                next(err);
              } else {
                next(null, seed, stdout);
              }
            });
        },
        function uploadResult(seed, result, next) {
            s3.putObject({
                Bucket: 'open-marathon',
                Key: 'codes/result/#1.txt'.replace('#1', seed),
                Body: result
            }, next);
        },
        function deleteMessage(data, next) {
            sqs.deleteMessage({
                QueueUrl: 'https://sqs.ap-northeast-1.amazonaws.com/002853820913/open-marathon-testcase',
                ReceiptHandle: ReceiptHandle
            }, function(err, data) {
                if (!err) {
                    context.done(err, 'Process complete!!');
                }
            });
            next(null);
        },
        function restartSelf(next) {
            lambda.invoke({
                FunctionName: 'executeExternalCode',
                InvocationType: 'Event'
            }, next);
        }
    ], function(err) {
    	  if (err) {
            console.log(err);
        }
        context.done(err, 'Process complete');
    });



    // sqs.receiveMessage(params, function(err, data) {
    //     if (err) {
    //         console.log(err, err.stack); // an error occurred
    //         context.done('empty queue');
    //     } else {
    //         if (data.Messages.length === 0) {
    //             context.done(null, 'nothing to do');
    //             return;
    //         }
    //         var messageId = data.Messages[0].MessageId;
    //         var ReceiptHandle = data.Messages[0].ReceiptHandle;
    //         var body = JSON.parse(data.Messages[0].Body);

    //         var remoteSolutionPath = body.MessageAttributes.solution.Value;
    //         var remoteGraderPath = body.MessageAttributes.grader.Value;
    //         var seed = body.MessageAttributes.seed.Value;

    //         // sqs.deleteMessage({
    //         //     QueueUrl: 'https://sqs.ap-northeast-1.amazonaws.com/002853820913/open-marathon-testcase',
    //         //     ReceiptHandle: ReceiptHandle
    //         // }, function(err, data) {
    //         //     if (!err) {
    //         //         context.done(err, 'Process complete!!');
    //         //     }
    //         // });

    //         console.log(data.Messages[0]);
    //         console.log(remoteSolutionPath);
    //         console.log(remoteGraderPath);
    //         console.log(seed);

    //         var solutionName = 'OpenMarathon.class';
    //         var graderName = 'SmallPolygonsGrader.jar';
    //         var localSolutionPath = '/tmp/' + solutionName;
    //         var localGraderPath = '/tmp/' + graderName;

    //         remoteSolutionPath = 'OpenMarathon.class'
    //         remoteGraderPath = 'grader/SmallPolygonsGrader.jar';

    //         var solutionFile = fs.createWriteStream(localSolutionPath);
    //         s3.getObject({
    //             Bucket: 'open-marathon',
    //             Key: remoteSolutionPath
    //         }).createReadStream().pipe(solutionFile);

    //         var graderFile = fs.createWriteStream(localGraderPath);
    //         s3.getObject({
    //             Bucket: 'open-marathon',
    //             Key: remoteGraderPath
    //         }).createReadStream().pipe(graderFile);

    //         var x = 0;
    //         for (var i = 0 ; i < 100000 ; i++) {
    //             x += i;
    //         }
    //         console.log(x);

    //         // java -jar artifacts/SmallPolygonsGrader/SmallPolygonsGrader.jar "java -cp /Users/hama_du/Desktop/tco15mr1/src SPBruteForce" "59"
    //         var command = 'java -jar #1'
    //             .replace('#1', localGraderPath)
    //             .replace('#2', seed);
    //         command = 'du -a /tmp';

    //         var theProcess = exec(command, function(error) {
    //             // Resolve with result of process
    //             if (!error) {
    //                 var resultPath = ''

    //                 // s3.putObject({
    //                 //     Bucket: 'open-marathon',
    //                 //     Key: 'test.txt',
    //                 //     Body: '114514'
    //                 // });
    //                 context.succeed('okay');
    //             }
    //         });
    //         theProcess.stdout.on('data', console.log);
    //         theProcess.stderr.on('data', console.error);
    //     }
    // });

    // // var bucket = event.Records[0].s3.bucket.name;
    // // var key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
    // // var params = {
    // //     Bucket: bucket,
    // //     Key: key
    // // };
    // // var file = require('fs').createWriteStream('/tmp/OpenMarathon.class');
    // // s3.getObject(params).createReadStream().pipe(file);



    // // s3.getObject(params, function(err, data) {
    // //     if (err) {
    // //         console.log(err);
    // //         var message = "Error getting object " + key + " from bucket " + bucket +
    // //             ". Make sure they exist and your bucket is in the same region as this function.";
    // //         console.log(message);
    // //         context.fail(message);
    // //     } else {
    // //         console.log('CONTENT:', data);
    // //         context.succeed(data.ContentType);
    // //     }
    // // });



    // // var child2 = exec('java -cp /tmp Grader "java -cp /tmp OpenMarathon"', function(error) {
    // //     // Resolve with result of process
    // //     context.done(error, 'Process complete: javac');
    // // });
    // // child2.stdout.on('data', console.log);
    // // child2.stderr.on('data', console.error);




    // // if (!event.cmd) {
    // //     context.fail('Please specify a command to run as event.cmd');
    // //     return;
    // // }
    // // child = exec(event.cmd, function(error) {
    // //     // Resolve with result of process
    // //     context.done(error, 'Process complete!');
    // // });
    // // Log process stdout and stderr
};
